A Pen created at CodePen.io. You can find this one at http://codepen.io/tjoen/pen/EojDs.

 found this on github, adapted the colors to make it more like the magnificent device I used to have. About 36 years ago ;)